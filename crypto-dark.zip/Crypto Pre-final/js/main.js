$(function() {
    var Accordion = function(el, multiple) {
        this.el = el || {};
        this.multiple = multiple || false;
  
        var links = this.el.find('.article-title');
        links.on('click', {
            el: this.el,
            multiple: this.multiple
        }, this.dropdown)
    }
  
    Accordion.prototype.dropdown = function(e) {
        var $el = e.data.el;
        $this = $(this),
            $next = $this.next();
  
        $next.slideToggle();
        $this.parent().toggleClass('open');
  
        if (!e.data.multiple) {
            $el.find('.accordion-content').not($next).slideUp().parent().removeClass('open');
        };
    }
    var accordion = new Accordion($('.accordion-container'), false);
  });
  
var cursor = document.getElementById("custom-cursor"),
	cursorDot = document.getElementById("custom-cursor-dot")
document.addEventListener("mousemove", function (e) {
	var t = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft,
		n = e.clientY + document.body.scrollTop + document.documentElement.scrollTop
	;(cursor.style.left = t + "px"), (cursor.style.top = n + "px"), (cursorDot.style.left = t + "px"), (cursorDot.style.top = n + "px")
})
for (var links = document.getElementsByTagName("a"), i = 0, len = links.length; i < len; i++)
	(links[i].onmouseenter = function () {
		mouseOver()
	}),
		(links[i].onmouseleave = function () {
			mouseOut()
		})
function mouseOver() {
	cursor.classList.add("hovering-link"), cursorDot.classList.add("hovering-link")
}
function mouseOut() {
	cursor.classList.remove("hovering-link"), cursorDot.classList.remove("hovering-link")
}
!(function (e) {
	"use strict"
	if (
		(jQuery(window).on("load", function () {
			jQuery("#status").fadeOut(), jQuery("#preloader").delay(350).fadeOut("slow")
		}),
		jQuery(".mobile-menu nav").meanmenu({ meanScreenWidth: "992" }),
		e(".lng-in").on("click", function () {
			e(".lng-out").slideToggle("slow")
		}),
		smoothScroll.init(),
		e("#pie_chart_1").length > 0 &&
			e("#pie_chart_1").easyPieChart({
				barColor: "#5e619c",
				lineWidth: 2,
				animate: 3e3,
				size: 100,
				lineCap: "square",
				scaleColor: !1,
				onStep: function (t, n, a) {
					e(this.el).find(".percent").text(Math.round(a))
				},
			}),
		e("#e_chart_3").length > 0)
	) {
		var t = {
			tooltip: { show: !0, trigger: "item", backgroundColor: "rgba(33,33,33,1)", borderRadius: 0, padding: 10, formatter: "{b}: {c} ({d}%)", textStyle: { color: "#fff", fontStyle: "normal", fontWeight: "normal", fontFamily: "'Roboto', sans-serif", fontSize: 12 } },
			series: [
				{
					type: "pie",
					selectedMode: "single",
					radius: ["90%", "30%"],
					color: ["#a8a9bd", "#9395b9", "#656790", "#3e406e"],
					labelLine: { normal: { show: !1 } },
					data: [
						{ value: 1945, name: "" },
						{ value: 2580, name: "" },
						{ value: 5160, name: "" },
						{ value: 54826, name: "" },
					],
				},
			],
		}
		;(n = echarts.init(document.getElementById("e_chart_3"))).setOption(t), n.resize()
	}
	if (e("#e_chart_2").length > 0) {
		var n
		t = {
			tooltip: { show: !0, trigger: "item", backgroundColor: "rgba(33,33,33,1)", borderRadius: 0, padding: 10, formatter: "{b}: {c} ({d}%)", textStyle: { color: "#fff", fontStyle: "normal", fontWeight: "normal", fontFamily: "'Roboto', sans-serif", fontSize: 12 } },
			series: [
				{
					type: "pie",
					selectedMode: "single",
					radius: ["90%", "30%"],
					color: ["#a8a9bd", "#9395b9", "#656790", "#3e406e"],
					labelLine: { normal: { show: !1 } },
					data: [
						{ value: 555555, name: "" },
						{ value: 58152, name: "" },
						{ value: 455025, name: "" },
						{ value: 255525, name: "" },
					],
				},
			],
		}
		;(n = echarts.init(document.getElementById("e_chart_2"))).setOption(t), n.resize()
	}
	function a(e) {
		var t = Date.parse(e) - Date.parse(new Date()),
			n = Math.floor((t / 1e3) % 60),
			a = Math.floor((t / 1e3 / 60) % 60),
			o = Math.floor((t / 36e5) % 24)
		return { total: t, days: Math.floor(t / 864e5), hours: o, minutes: a, seconds: n }
	}
	function o(e, t) {
		var n = document.getElementById(e),
			o = n.querySelector(".days"),
			i = n.querySelector(".hours"),
			s = n.querySelector(".minutes"),
			l = n.querySelector(".seconds")
		function r() {
			var e = a(t)
			;(o.innerHTML = e.days), (i.innerHTML = ("0" + e.hours).slice(-2)), (s.innerHTML = ("0" + e.minutes).slice(-2)), (l.innerHTML = ("0" + e.seconds).slice(-2)), e.total <= 0 && clearInterval(c)
		}
		r()
		var c = setInterval(r, 1e3)
	}
	function a(e) {
		var t = Date.parse(e) - Date.parse(new Date()),
			n = Math.floor((t / 1e3) % 60),
			a = Math.floor((t / 1e3 / 60) % 60),
			o = Math.floor((t / 36e5) % 24)
		return { total: t, days: Math.floor(t / 864e5), hours: o, minutes: a, seconds: n }
	}
	function o(e, t) {
		var n = document.getElementById(e),
			o = n.querySelector(".days"),
			i = n.querySelector(".hours"),
			s = n.querySelector(".minutes"),
			l = n.querySelector(".seconds")
		function r() {
			var e = a(t)
			;(o.innerHTML = e.days), (i.innerHTML = ("0" + e.hours).slice(-2)), (s.innerHTML = ("0" + e.minutes).slice(-2)), (l.innerHTML = ("0" + e.seconds).slice(-2)), e.total <= 0 && clearInterval(c)
		}
		r()
		var c = setInterval(r, 1e3)
	}
	new WOW().init(),
		e(".blog-slider").owlCarousel({ autoPlay: !1, slideSpeed: 2e3, pagination: !1, navigation: !0, items: 3, navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"], itemsDesktop: [1199, 3], itemsDesktopSmall: [992, 2], itemsTablet: [768, 2], itemsMobile: [480, 1] }),
		e(".tokes-chart-slider").owlCarousel({ autoPlay: !1, slideSpeed: 2e3, pagination: !1, navigation: !0, items: 1, navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"], itemsDesktop: [1199, 1], itemsDesktopSmall: [992, 1], itemsTablet: [768, 1], itemsMobile: [479, 1] }),
		(function (e) {
			function t(t) {
				t.each(function () {
					var t = e(this),
						n = t.data("animation")
					t.addClass(n).one("webkitAnimationEnd animationend", function () {
						t.removeClass(n)
					})
				})
			}
			var n = e("#carousel-example-generic"),
				a = n.find(".item:first").find("[data-animation ^= 'animated']")
			n.carousel(),
				t(a),
				n.carousel("pause"),
				n.on("slide.bs.carousel", function (n) {
					t(e(n.relatedTarget).find("[data-animation ^= 'animated']"))
				})
		})(jQuery),
		o("clockdiv", "june 1 2018 11:59:00 GMT-0400"),
		o("clockdiv2", "june 1 2018 11:59:00 GMT-0400"),
		e(".wd_single_index_menu ul li a").on("click", function (t) {
			e(".wd_single_index_menu ul li").removeClass("active"), e(this).parent().addClass("active")
			var n = e("[section-scroll=" + e(this).attr("href") + "]")
			t.preventDefault()
			var a = n.offset().top - parseInt("80", 10)
			e("html, body").animate({ scrollTop: a }, 1e3)
		}),
		e(window).scroll(function () {
			var t = e(window).scrollTop(),
				n = e(".wd_single_index_menu ul li")
			t >= 0
				? e("[section-scroll]").each(function (a) {
						e(this).position().top <= t + 90 && (n.removeClass("active"), n.eq(a).addClass("active"))
				  })
				: (n.removeClass("active"), e(".wd_single_index_menu ul li:first").addClass("active"))
		}),
		e("#cssmenu ul li a").on("click", function (t) {
			e("#cssmenu ul li").removeClass("active"), e(this).parent().addClass("active")
			var n = e("[section-scroll=" + e(this).attr("href") + "]")
			t.preventDefault()
			var a = n.offset().top - parseInt("80", 10)
			e("html, body").animate({ scrollTop: a }, 1e3)
		}),
		e(window).scroll(function () {
			var t = e(window).scrollTop(),
				n = e("#cssmenu ul li")
			t >= 0
				? e("[section-scroll]").each(function (a) {
						e(this).position().top <= t + 90 && (n.removeClass("active"), n.eq(a).addClass("active"))
				  })
				: (n.removeClass("active"), e("#cssmenu ul li:first").addClass("active"))
		}),
		e(window).scroll(function () {
			e(window).scrollTop() + 1 > 800 ? e(".gc_main_menu_wrapper").addClass("menu_fixed animated fadeInDown") : e(".gc_main_menu_wrapper").removeClass("menu_fixed animated fadeInDown")
		}),
		e("#toggle").on("click", function () {
			var t = e("#sidebar").width()
			0 == e("#sidebar").offset().left ? e("#sidebar").animate({ left: -t }, "slow") : e("#sidebar").animate({ left: "0" }, "slow")
		}),
		e("#toggle_close").on("click", function () {
			var t = e("#sidebar").width()
			0 == e("#sidebar").offset().left ? e("#sidebar").animate({ left: -t }, "slow") : e("#sidebar").animate({ left: "0" }, "slow")
		}),
		e.scrollUp({ scrollText: '<i class="fa fa-angle-up"></i>', easingType: "linear", scrollSpeed: 900, animation: "fade" })
})(jQuery),
	particlesJS("particles-js", {
		particles: {
			number: { value: 100, density: { enable: !0, value_area: 1e3 } },
			color: { value: ["#fff", "#fff", "#fff", "#fff"] },
			shape: { type: "circle", stroke: { width: 0, color: "#b3b4ca" }, polygon: { nb_sides: 5 }, image: { src: "img/github.svg", width: 100, height: 100 } },
			opacity: { value: 0.6, random: !1, anim: { enable: !1, speed: 1, opacity_min: 0.1, sync: !1 } },
			size: { value: 2, random: !0, anim: { enable: !1, speed: 40, size_min: 0.1, sync: !1 } },
			line_linked: { enable: !0, distance: 120, color: "#b3b4ca", opacity: 0.4, width: 1 },
		},
		interactivity: { detect_on: "canvas", events: { onhover: { enable: !0, mode: "grab" }, onclick: { enable: !1 }, resize: !0 }, modes: { grab: { distance: 140, line_linked: { opacity: 1 } }, bubble: { distance: 400, size: 40, duration: 2, opacity: 8, speed: 3 }, repulse: { distance: 200, duration: 0.4 }, push: { particles_nb: 4 }, remove: { particles_nb: 2 } } },
		retina_detect: !0,
	}),
	$(window).scroll(function () {
		$(this).scrollTop() >= 100 ? $("#return-to-top").fadeIn(200) : $("#return-to-top").fadeOut(200)
	}),
	$("#return-to-top").click(function () {
		$("body,html").animate({ scrollTop: 0 }, 500)
	})
